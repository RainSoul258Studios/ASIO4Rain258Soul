﻿Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "  EJECUTANDO PRUEBAS LOCALES DE ASIO4Rain258Soul (v1.0.258)" -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan

$BridgeExe = Join-Path $PSScriptRoot "bin\ASIO4Rain258SoulBridge.exe"
if (Test-Path $BridgeExe) {
    & $BridgeExe --verify
}
$ConsoleHtml = Join-Path $PSScriptRoot "web\index.html"
if (Test-Path $ConsoleHtml) {
    Write-Host "[TEST UI] Abriendo consola interactiva 3D en el navegador..." -ForegroundColor Green
    Start-Process $ConsoleHtml
}
