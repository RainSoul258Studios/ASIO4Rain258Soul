﻿export class DSPTelemetryScanner {
    constructor(audioContext, sourceNode) {
        this.ctx = audioContext;
        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 2048;
        this.freqData = new Float32Array(this.analyser.frequencyBinCount);
        this.timeData = new Float32Array(this.analyser.fftSize);
        sourceNode.connect(this.analyser);
        this.lastCentroidHz = 1000;
    }
    scanFrame() {
        this.analyser.getFloatFrequencyData(this.freqData);
        this.analyser.getFloatTimeDomainData(this.timeData);
        let weightedSum = 0, magnitudeSum = 0;
        const binHz = (this.ctx.sampleRate / 2) / this.freqData.length;
        for (let i = 0; i < this.freqData.length; i++) {
            const mag = Math.pow(10, this.freqData[i] / 20);
            weightedSum += (i * binHz) * mag;
            magnitudeSum += mag;
        }
        const currentCentroidHz = magnitudeSum > 0 ? (weightedSum / magnitudeSum) : 0;
        const sweepDirection = currentCentroidHz > this.lastCentroidHz + 15 ? "▲ SUBIENDO" :
                               currentCentroidHz < this.lastCentroidHz - 15 ? "▼ BAJANDO" : "● ESTABLE";
        this.lastCentroidHz = currentCentroidHz;
        let rms = 0;
        for (let i = 0; i < this.timeData.length; i++) rms += this.timeData[i] * this.timeData[i];
        rms = Math.sqrt(rms / this.timeData.length);
        return { cutoffCentroidHz: Math.round(currentCentroidHz), filterSweepState: sweepDirection, automationEnvelopeRMS: rms.toFixed(3) };
    }
}
