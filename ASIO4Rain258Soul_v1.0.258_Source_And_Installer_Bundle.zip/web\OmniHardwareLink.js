﻿export class OmniNativeBridge {
    constructor(url = "ws://127.0.0.1:8258") {
        try {
            this.ws = new WebSocket(url);
            this.ws.onopen = () => console.log("[ASIO4Rain258Soul] Conectado al puente IPC en 127.0.0.1:8258");
        } catch (e) {}
    }
}
window.omniBridge = new OmniNativeBridge();
