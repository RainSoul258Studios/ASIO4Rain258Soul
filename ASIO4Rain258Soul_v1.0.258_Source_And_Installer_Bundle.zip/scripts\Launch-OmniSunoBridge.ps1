﻿Write-Host "=== ASIO4Rain258Soul - Puente Boom 3D + Suno Studio W11 ===" -ForegroundColor Cyan
$boomDevice = Get-PnpDevice -Class AudioEndpoint -ErrorAction SilentlyContinue | Where-Object { $_.FriendlyName -match "Boom" -and $_.Status -eq "OK" }
if ($boomDevice) {
    Write-Host "[OK] Boom Audio Device WDM detectado: $($boomDevice.FriendlyName)" -ForegroundColor Green
    Write-Host " -> Guardia Anti-Doble-HRTF (Phase Shield): ACTIVA" -ForegroundColor Yellow
} else {
    Write-Host "[INFO] Boom Audio Device no detectado. Operando en bus ASIO/WASAPI directo." -ForegroundColor Gray
}
$chromePath = "${env:ProgramFiles}\Google\Chrome\Application\chrome.exe"
$wasapiFlags = @("--audio-buffer-size=64", "--disable-audio-output-resampler", "--enable-exclusive-audio", "https://suno.com")
if (Test-Path $chromePath) { Start-Process -FilePath $chromePath -ArgumentList $wasapiFlags }
