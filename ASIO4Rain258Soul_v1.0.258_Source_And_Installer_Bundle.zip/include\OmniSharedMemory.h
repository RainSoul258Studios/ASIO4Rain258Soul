﻿#pragma once
#include <windows.h>
#include <atomic>
#include <cstdint>

static constexpr wchar_t OMNI_IPC_MAP_NAME[] = L"Global\\ASIO4Rain258Soul_IPC_v1";

#pragma pack(push, 8)
struct OmniIPCControlBlock {
    std::atomic<uint32_t> sequenceVersion;
    uint32_t asioBufferSamples;        // 64 a 2048 muestras
    bool     wdmDeviceActive[4];       // 0: USB Mic/Guitar, 1: Boom 3D WDM, 2: Suno WASAPI, 3: Virtual Cable
    bool     boom3DSurroundActive;     // Detecta efecto 3D Surround en Boom 3D
    bool     boom3DZeroLatencyBypass;  // Smart Rec-Arm: salta los ~32.0 ms de Boom 3D al grabar en Suno
    bool     phaseShieldEnabled;       // Guardia Anti-Doble-HRTF (Pre-Posicionador Azimuth + Excitador Sub)

    struct Node3D {
        float azimuthDeg;              // -180.0f a +180.0f
        float elevationDeg;            // -90.0f a +90.0f
        float distanceMeters;          // 0.2f a 5.0f
        float eq3BanddB[3];            // Low, Mid, High
        bool  phaseInvert;             // Ø FASE
        bool  mute;
        bool  solo;
        bool  hrtfEnabled;
        bool  routeBus[4];             // OUT A (ASIO), OUT B (HRTF), OUT C (OBS), OUT D (DAW)
    } channels[6];

    float eq64GainsLinear[64];         // Rack Maestro: EQ de 64 Bandas (20 Hz - 20 kHz)
    bool  la2aLimitMode;               // false = COMP (3:1), true = LIMIT (inf:1)
    float la2aPeakReduction;           // 0.0f a 100.0f
    float la2aMakeupLinear;
    float la2aR37HFEmphasis;
    float la2aTubeWarmth;              // Saturación de válvulas 12AX7A / 6AQ5

    std::atomic<float> telemetryLA2AGainReductiondB;
    std::atomic<float> telemetryCutoffHz;
    std::atomic<float> telemetryEnvelopeRMS;
    std::atomic<float> telemetryLFORateHz;
    std::atomic<float> telemetrySunoTotalOffsetMs; // ~17.8 ms en Bypass vs ~49.8 ms con Boom 3D
};
#pragma pack(pop)

class OmniSharedMemoryManager {
private:
    HANDLE m_hMapFile = nullptr;
    OmniIPCControlBlock* m_pBlock = nullptr;

public:
    bool Initialize(bool createAsServer) {
        if (createAsServer) {
            m_hMapFile = CreateFileMappingW(
                INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
                0, sizeof(OmniIPCControlBlock), OMNI_IPC_MAP_NAME);
            if (!m_hMapFile) {
                m_hMapFile = CreateFileMappingW(
                    INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE,
                    0, sizeof(OmniIPCControlBlock), L"Local\\ASIO4Rain258Soul_IPC_v1");
            }
        } else {
            m_hMapFile = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, OMNI_IPC_MAP_NAME);
            if (!m_hMapFile) {
                m_hMapFile = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, L"Local\\ASIO4Rain258Soul_IPC_v1");
            }
        }
        if (!m_hMapFile) return false;
        m_pBlock = static_cast<OmniIPCControlBlock*>(
            MapViewOfFile(m_hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(OmniIPCControlBlock)));
        return (m_pBlock != nullptr);
    }

    OmniIPCControlBlock* GetBlock() const noexcept { return m_pBlock; }

    ~OmniSharedMemoryManager() {
        if (m_pBlock) UnmapViewOfFile(m_pBlock);
        if (m_hMapFile) CloseHandle(m_hMapFile);
    }
};
