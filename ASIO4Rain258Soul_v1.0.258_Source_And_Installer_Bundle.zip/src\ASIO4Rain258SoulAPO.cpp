﻿#include "ASIO4Rain258SoulAPO.h"
#include <new>

static HMODULE g_hModule = nullptr;
static std::atomic<long> g_serverLocks{0};

CASIO4Rain258SoulAPO::CASIO4Rain258SoulAPO() {
    g_serverLocks.fetch_add(1, std::memory_order_relaxed);
    LoadDefaultState();
    m_ipcClient.Initialize(false);
}

CASIO4Rain258SoulAPO::~CASIO4Rain258SoulAPO() {
    g_serverLocks.fetch_sub(1, std::memory_order_relaxed);
}

STDMETHODIMP CASIO4Rain258SoulAPO::QueryInterface(REFIID riid, void** ppvObject) {
    if (!ppvObject) return E_POINTER;
    if (riid == IID_IUnknown || riid == CLSID_ASIO4Rain258SoulAPO) {
        *ppvObject = static_cast<IUnknown*>(this);
        AddRef();
        return S_OK;
    }
    *ppvObject = nullptr;
    return E_NOINTERFACE;
}

STDMETHODIMP_(ULONG) CASIO4Rain258SoulAPO::AddRef() {
    return InterlockedIncrement(&m_refCount);
}

STDMETHODIMP_(ULONG) CASIO4Rain258SoulAPO::Release() {
    ULONG count = InterlockedDecrement(&m_refCount);
    if (count == 0) delete this;
    return count;
}

void CASIO4Rain258SoulAPO::LoadDefaultState() noexcept {
    m_localCache.asioBufferSamples = 256;
    m_localCache.boom3DSurroundActive = true;
    m_localCache.boom3DZeroLatencyBypass = false;
    m_localCache.phaseShieldEnabled = true;

    m_localCache.channels[0].azimuthDeg = -35.0f;
    m_localCache.channels[0].elevationDeg = 15.0f;
    m_localCache.channels[0].distanceMeters = 1.2f;
    m_localCache.channels[0].phaseInvert = false;

    for (int i = 0; i < 64; ++i) m_localCache.eq64GainsLinear[i] = 1.0f;
    // Curva Suno AI Master Polish: atenúa barro 250-400 Hz (0.749) y realza aire 12-16 kHz (1.412)
    for (int i = 16; i <= 21; ++i) m_localCache.eq64GainsLinear[i] = 0.749f;
    for (int i = 54; i <= 59; ++i) m_localCache.eq64GainsLinear[i] = 1.412f;

    m_localCache.la2aLimitMode = false;
    m_localCache.la2aPeakReduction = 42.0f;
    m_localCache.la2aMakeupLinear = 1.412f;
    m_localCache.la2aR37HFEmphasis = 0.35f;
    m_localCache.la2aTubeWarmth = 0.28f;
}

void CASIO4Rain258SoulAPO::SyncFromSharedMemory() noexcept {
    OmniIPCControlBlock* pShared = m_ipcClient.GetBlock();
    if (!pShared) return;

    uint32_t currentVer = pShared->sequenceVersion.load(std::memory_order_acquire);
    if (currentVer != m_lastSyncVersion) {
        m_localCache.asioBufferSamples = pShared->asioBufferSamples;
        m_localCache.boom3DSurroundActive = pShared->boom3DSurroundActive;
        m_localCache.boom3DZeroLatencyBypass = pShared->boom3DZeroLatencyBypass;
        m_localCache.phaseShieldEnabled = pShared->phaseShieldEnabled;
        m_localCache.channels[0] = pShared->channels[0];

        for (int i = 0; i < 64; ++i) {
            m_localCache.eq64GainsLinear[i] = pShared->eq64GainsLinear[i];
        }

        m_localCache.la2aLimitMode = pShared->la2aLimitMode;
        m_localCache.la2aPeakReduction = pShared->la2aPeakReduction;
        m_localCache.la2aMakeupLinear = pShared->la2aMakeupLinear;
        m_localCache.la2aR37HFEmphasis = pShared->la2aR37HFEmphasis;
        m_localCache.la2aTubeWarmth = pShared->la2aTubeWarmth;

        m_lastSyncVersion = currentVer;
    }
}

STDMETHODIMP CASIO4Rain258SoulAPO::Initialize(UINT32 cbDataSize, BYTE* pbyData) {
    if (pbyData == nullptr && cbDataSize != 0) return E_INVALIDARG;
    return S_OK;
}

inline void CASIO4Rain258SoulAPO::ProcessPhaseShieldAndSpatial(float& L, float& R) noexcept {
    const auto& ch = m_localCache.channels[0];
    const float radAzimuth = ch.azimuthDeg * (3.14159265f / 180.0f);
    const float attenDist = 1.0f / std::max(1.0f, ch.distanceMeters * 0.85f);
    const float panL = std::cos((radAzimuth + 1.570796f) * 0.5f) * attenDist;
    const float panR = std::sin((radAzimuth + 1.570796f) * 0.5f) * attenDist;

    if (m_localCache.boom3DSurroundActive && m_localCache.phaseShieldEnabled && !m_localCache.boom3DZeroLatencyBypass) {
        float subMono = (L + R) * 0.5f;
        float subHarmonic = std::tanh(subMono * 2.2f) * 0.12f;
        L = (L * panL) + subHarmonic;
        R = (R * panR) + subHarmonic;
    } else {
        m_delayLineL[m_delayWriteIdx] = L;
        m_delayLineR[m_delayWriteIdx] = R;

        int itdOffset = static_cast<int>(std::fabs(std::sin(radAzimuth)) * 22.0f);
        int readIdxL = (m_delayWriteIdx - (ch.azimuthDeg > 0.0f ? itdOffset : 0) + MAX_ITD_SAMPLES) % MAX_ITD_SAMPLES;
        int readIdxR = (m_delayWriteIdx - (ch.azimuthDeg < 0.0f ? itdOffset : 0) + MAX_ITD_SAMPLES) % MAX_ITD_SAMPLES;

        L = m_delayLineL[readIdxL] * panL;
        R = m_delayLineR[readIdxR] * panR;
        m_delayWriteIdx = (m_delayWriteIdx + 1) % MAX_ITD_SAMPLES;
    }
}

inline void CASIO4Rain258SoulAPO::ProcessLA2AOptical(float& L, float& R) noexcept {
    float sidechain = (std::fabs(L) + std::fabs(R)) * 0.5f * (1.0f + m_localCache.la2aR37HFEmphasis * 0.4f);
    float drive = sidechain * (m_localCache.la2aPeakReduction / 35.0f);

    if (drive > m_t4bFastEnv) {
        m_t4bFastEnv = 0.992f * m_t4bFastEnv + 0.008f * drive;
        m_t4bSlowMemory = 0.9995f * m_t4bSlowMemory + 0.0005f * drive;
    } else {
        m_t4bFastEnv *= 0.9992f;
        m_t4bSlowMemory *= 0.99992f;
    }

    float envTotal = (m_t4bFastEnv * 0.7f) + (m_t4bSlowMemory * 0.3f);
    float ratio = m_localCache.la2aLimitMode ? 100.0f : 3.0f;
    float gainReductiondB = 0.0f;

    if (envTotal > 0.15f) {
        gainReductiondB = (envTotal - 0.15f) * (1.0f - (1.0f / ratio)) * 18.0f;
    }

    if (OmniIPCControlBlock* pShared = m_ipcClient.GetBlock()) {
        pShared->telemetryLA2AGainReductiondB.store(gainReductiondB, std::memory_order_relaxed);
    }

    float grLinear = std::pow(10.0f, -gainReductiondB / 20.0f) * m_localCache.la2aMakeupLinear;
    L *= grLinear;
    R *= grLinear;

    const float warmth = 1.0f + m_localCache.la2aTubeWarmth;
    L = std::tanh(L * warmth) / std::tanh(warmth);
    R = std::tanh(R * warmth) / std::tanh(warmth);
}

void CASIO4Rain258SoulAPO::APOProcessRT(UINT32 frames, float* pInBuf, float* pOutBuf) noexcept {
    if (!pInBuf || !pOutBuf || frames == 0) return;
    SyncFromSharedMemory();

    const float mudCutGain   = m_localCache.eq64GainsLinear[18];
    const float airBoostGain = m_localCache.eq64GainsLinear[56];
    const float compositeEQ  = (mudCutGain * 0.45f) + (airBoostGain * 0.55f);

    float accumRMS = 0.0f;
    float prevL = 0.0f;
    float zeroCrossCount = 0.0f;

    for (UINT32 i = 0; i < frames; ++i) {
        float L = pInBuf[i * m_channels];
        float R = (m_channels > 1) ? pInBuf[i * m_channels + 1] : L;

        if (m_localCache.channels[0].phaseInvert) {
            L = -L;
            R = -R;
        }

        ProcessPhaseShieldAndSpatial(L, R);
        L *= compositeEQ;
        R *= compositeEQ;
        ProcessLA2AOptical(L, R);

        accumRMS += (L * L + R * R) * 0.5f;
        if ((prevL < 0.0f && L >= 0.0f) || (prevL >= 0.0f && L < 0.0f)) {
            zeroCrossCount += 1.0f;
        }
        prevL = L;

        pOutBuf[i * m_channels] = L;
        if (m_channels > 1) pOutBuf[i * m_channels + 1] = R;
    }

    if (OmniIPCControlBlock* pShared = m_ipcClient.GetBlock()) {
        pShared->telemetryEnvelopeRMS.store(std::sqrt(accumRMS / static_cast<float>(frames)), std::memory_order_relaxed);
        pShared->telemetryCutoffHz.store((zeroCrossCount / (2.0f * static_cast<float>(frames))) * m_sampleRate, std::memory_order_relaxed);
    }
}

class CASIO4Rain258SoulClassFactory : public IClassFactory {
public:
    STDMETHODIMP QueryInterface(REFIID riid, void** ppvObject) override {
        if (!ppvObject) return E_POINTER;
        if (riid == IID_IUnknown || riid == IID_IClassFactory) {
            *ppvObject = static_cast<IClassFactory*>(this);
            AddRef();
            return S_OK;
        }
        *ppvObject = nullptr;
        return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef() override { return 2; }
    STDMETHODIMP_(ULONG) Release() override { return 1; }
    STDMETHODIMP CreateInstance(IUnknown* pUnkOuter, REFIID riid, void** ppvObject) override {
        if (pUnkOuter != nullptr) return CLASS_E_NOAGGREGATION;
        CASIO4Rain258SoulAPO* pApo = new (std::nothrow) CASIO4Rain258SoulAPO();
        if (!pApo) return E_OUTOFMEMORY;
        HRESULT hr = pApo->QueryInterface(riid, ppvObject);
        pApo->Release();
        return hr;
    }
    STDMETHODIMP LockServer(BOOL fLock) override {
        if (fLock) g_serverLocks.fetch_add(1, std::memory_order_relaxed);
        else g_serverLocks.fetch_sub(1, std::memory_order_relaxed);
        return S_OK;
    }
};

static CASIO4Rain258SoulClassFactory g_ClassFactory;

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID) {
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
    }
    return TRUE;
}

extern "C" HRESULT __stdcall DllCanUnloadNow(void) {
    return (g_serverLocks.load(std::memory_order_relaxed) == 0) ? S_OK : S_FALSE;
}

extern "C" HRESULT __stdcall DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv) {
    if (rclsid != CLSID_ASIO4Rain258SoulAPO) return CLASS_E_CLASSNOTAVAILABLE;
    return g_ClassFactory.QueryInterface(riid, ppv);
}

extern "C" HRESULT __stdcall DllRegisterServer(void) {
    wchar_t modulePath[MAX_PATH] = { 0 };
    GetModuleFileNameW(g_hModule, modulePath, MAX_PATH);

    const wchar_t* clsidKey  = L"SOFTWARE\\Classes\\CLSID\\{8F258A10-4D3E-4B9A-9C12-FA0258003D01}";
    const wchar_t* inprocKey = L"SOFTWARE\\Classes\\CLSID\\{8F258A10-4D3E-4B9A-9C12-FA0258003D01}\\InprocServer32";

    HKEY hKey = nullptr;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, clsidKey, 0, nullptr, 0, KEY_WRITE, nullptr, &hKey, nullptr) != ERROR_SUCCESS)
        return E_FAIL;
    const wchar_t* desc = L"ASIO4Rain258Soul // OMNI-MATRIX 3D Audio Driver APO";
    RegSetValueExW(hKey, nullptr, 0, REG_SZ, reinterpret_cast<const BYTE*>(desc), static_cast<DWORD>((wcslen(desc) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey);

    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, inprocKey, 0, nullptr, 0, KEY_WRITE, nullptr, &hKey, nullptr) != ERROR_SUCCESS)
        return E_FAIL;
    RegSetValueExW(hKey, nullptr, 0, REG_SZ, reinterpret_cast<const BYTE*>(modulePath), static_cast<DWORD>((wcslen(modulePath) + 1) * sizeof(wchar_t)));
    const wchar_t* threading = L"Both";
    RegSetValueExW(hKey, L"ThreadingModel", 0, REG_SZ, reinterpret_cast<const BYTE*>(threading), static_cast<DWORD>((wcslen(threading) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey);
    return S_OK;
}

extern "C" HRESULT __stdcall DllUnregisterServer(void) {
    RegDeleteTreeW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Classes\\CLSID\\{8F258A10-4D3E-4B9A-9C12-FA0258003D01}");
    return S_OK;
}
