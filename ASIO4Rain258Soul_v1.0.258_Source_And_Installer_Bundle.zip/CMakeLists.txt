﻿cmake_minimum_required(VERSION 3.20)
project(ASIO4Rain258Soul VERSION 1.0.258 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(MSVC)
    add_compile_options(/W3 /O2 /Oi /Ot /arch:AVX2 /fp:fast /MP /EHsc)
    add_compile_definitions(
        _WIN32_WINNT=0x0A00
        NOMINMAX
        WIN32_LEAN_AND_MEAN
        PROGRAM_NAME_W=L"ASIO4Rain258Soul"
    )
endif()

add_library(ASIO4Rain258SoulAPO SHARED
    src/ASIO4Rain258SoulAPO.cpp
    include/ASIO4Rain258SoulAPO.h
    include/OmniSharedMemory.h
    driver/ASIO4Rain258SoulAPO.def
)
target_include_directories(ASIO4Rain258SoulAPO PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/include")
target_link_libraries(ASIO4Rain258SoulAPO PRIVATE avrt ksuser mmdevapi ole32 uuid winmm advapi32)

add_executable(ASIO4Rain258SoulBridge
    src/ASIO4Rain258SoulBridge.cpp
    include/OmniSharedMemory.h
)
target_include_directories(ASIO4Rain258SoulBridge PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/include")
target_link_libraries(ASIO4Rain258SoulBridge PRIVATE ws2_32 winmm avrt advapi32)
